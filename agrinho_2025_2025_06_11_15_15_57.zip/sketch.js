// Variáveis Globais
let gameState = 'start'; // 'start', 'playing', 'gameOver'

let varaX;
let varaY;
let varaBaseY; // Posição Y da vara quando não está pescando
let isFishing = false; // Se a vara está descendo/subindo
let fishingSpeed = 8; // Velocidade de descida/subida da vara

let items = []; // Array para guardar os itens juninos (milho, pipoca, etc.)
let numItems = 5; // Quantidade de itens na tela
let itemImages = []; // Array para carregar as imagens dos itens

let score = 0;
let gameTimer = 30; // 30 segundos de jogo
let countdownInterval; // Para o temporizador

// --- PRÉ-CARREGAMENTO DE RECURSOS ---
function preload() {
  // Carregue as imagens dos itens aqui
  // itemImages.push(loadImage('assets/milho.png'));
  // itemImages.push(loadImage('assets/pipoca.png'));
  // ... e assim por diante para cada item
  // Se não tiver imagens, pode desenhar as formas simples (círculos, retângulos)
}

// --- CONFIGURAÇÃO INICIAL ---
function setup() {
  createCanvas(800, 600);
  varaBaseY = 50; // Posição Y inicial da vara (no topo da tela)
  varaY = varaBaseY;

  // Crie os itens iniciais
  for (let i = 0; i < numItems; i++) {
    createItem();
  }

  // Define o intervalo para o temporizador do jogo
  countdownInterval = setInterval(handleTimer, 1000);
}

// --- DESENHO E LÓGICA PRINCIPAL ---
function draw() {
  background(100, 150, 255); // Céu (azul)
  fill(0, 100, 200); // Água (azul mais escuro)
  rect(0, height / 2, width, height / 2); // Metade inferior da tela é água

  // Desenha algumas bandeirinhas (exemplo simples)
  fill(255, 0, 0); triangle(50, 50, 70, 50, 60, 70);
  fill(0, 255, 0); triangle(100, 40, 120, 40, 110, 60);
  // Adicione mais bandeirinhas e decorações juninas

  // Gerenciamento de estados do jogo
  if (gameState === 'start') {
    drawStartScreen();
  } else if (gameState === 'playing') {
    drawGame();
  } else if (gameState === 'gameOver') {
    drawGameOverScreen();
  }
}

// --- FUNÇÕES DE ESTADO DO JOGO ---

function drawStartScreen() {
  fill(255);
  textSize(40);
  textAlign(CENTER, CENTER);
  text('Pescaria Junina!', width / 2, height / 2 - 50);
  textSize(20);
  text('Mova o mouse para controlar a vara.', width / 2, height / 2);
  text('Clique ou aperte ESPAÇO para pescar.', width / 2, height / 2 + 30);
  text('Pressione ESPAÇO para começar!', width / 2, height / 2 + 80);
}

function drawGame() {
  // Atualiza a posição X da vara com o mouse
  varaX = mouseX;
  varaX = constrain(varaX, 50, width - 50); // Limita a vara na tela

  // Lógica da vara de pesca
  if (isFishing) {
    varaY += fishingSpeed; // Desce
    if (varaY > height - 50) { // Se a vara atingiu o fundo ou limite de pesca
      fishingSpeed *= -1; // Inverte o movimento (começa a subir)
    }
    if (varaY < varaBaseY && fishingSpeed < 0) { // Se a vara voltou ao topo
      isFishing = false;
      varaY = varaBaseY;
      fishingSpeed = abs(fishingSpeed); // Reseta a velocidade para descer
    }
  }

  // Desenha a vara de pesca
  stroke(139, 69, 19); // Marrom
  strokeWeight(5);
  line(varaX, 0, varaX, varaY); // Parte da vara
  stroke(255, 0, 0); // Linha da pesca (vermelha)
  strokeWeight(2);
  line(varaX, varaY, varaX, varaY + 20); // Anzol (pequena extensão da linha)

  // Desenha e atualiza os itens juninos
  for (let i = 0; i < items.length; i++) {
    let item = items[i];

    // Movimento do item
    item.x += item.speed;
    if (item.x > width + 50 || item.x < -50) { // Saiu da tela, reposiciona
      item.x = (item.speed > 0) ? -50 : width + 50;
      item.y = random(height / 2 + 50, height - 50); // Nova altura na água
    }

    // Desenha o item (use image() se tiver, senão desenhe formas)
    // Exemplo com círculo para um item "pipoca"
    fill(255, 255, 0); // Amarelo
    ellipse(item.x, item.y, 40, 40); // Desenha o "milho" ou "pipoca"

    // Detecção de colisão (pesca)
    if (isFishing && varaY + 20 >= item.y - 20 && varaY + 20 <= item.y + 20 &&
        dist(varaX, varaY + 20, item.x, item.y) < 30) { // Ajuste o 30 conforme o tamanho do anzol e item
      score += 1;
      // Reinicia o item pescado para uma nova posição e lado
      item.x = (item.speed > 0) ? -50 : width + 50;
      item.y = random(height / 2 + 50, height - 50);
    }
  }

  // Exibe pontuação e tempo
  fill(255);
  textSize(24);
  text('Pontos: ' + score, 20, 30);
  text('Tempo: ' + gameTimer, width - 120, 30);
}

function drawGameOverScreen() {
  fill(255);
  textSize(50);
  textAlign(CENTER, CENTER);
  text('Fim de Jogo!', width / 2, height / 2 - 50);
  textSize(30);
  text('Sua Pontuação: ' + score, width / 2, height / 2 + 10);
  text('Pressione R para jogar novamente', width / 2, height / 2 + 60);
}

// --- FUNÇÕES DE EVENTOS ---

function keyPressed() {
  if (gameState === 'start' && keyCode === 32) { // Tecla ESPAÇO
    startGame();
  } else if (gameState === 'playing' && keyCode === 32 && !isFishing) {
    isFishing = true; // Inicia a pesca
  } else if (gameState === 'gameOver' && keyCode === 82) { // Tecla R
    resetGame();
  }
}

function mousePressed() {
  if (gameState === 'playing' && !isFishing) {
    isFishing = true; // Inicia a pesca com clique do mouse
  }
}

// --- FUNÇÕES AUXILIARES ---

function createItem() {
  let initialX = random() > 0.5 ? -50 : width + 50; // Começa da esquerda ou direita
  let speed = random(1, 3);
  if (initialX > width / 2) {
    speed *= -1; // Se começar da direita, move para a esquerda
  }
  items.push({
    x: initialX,
    y: random(height / 2 + 50, height - 50), // Altura na água
    speed: speed,
    // img: random(itemImages) // Se estiver usando imagens
  });
}

function handleTimer() {
  if (gameState === 'playing') {
    gameTimer--;
    if (gameTimer <= 0) {
      gameState = 'gameOver';
      clearInterval(countdownInterval); // Para o temporizador
    }
  }
}

function startGame() {
  gameState = 'playing';
  score = 0;
  gameTimer = 30;
  // Reinicia os itens
  items = [];
  for (let i = 0; i < numItems; i++) {
    createItem();
  }
  // Reinicia o temporizador, caso já estivesse rodando de um jogo anterior
  clearInterval(countdownInterval);
  countdownInterval = setInterval(handleTimer, 1000);
}

function resetGame() {
  gameState = 'start'; // Volta para a tela inicial
  // A função startGame() vai resetar o jogo quando for chamada novamente
}